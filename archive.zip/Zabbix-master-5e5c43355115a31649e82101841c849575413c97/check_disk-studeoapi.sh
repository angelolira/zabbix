#!/bin/sh
FILE=/root/info.txt
rm -f /root/info.txt
#echo " " > /root/info.txt

df -H | grep -vE '^Filesystem|tmpfs|cdrom|boot' | awk '{ print $5 " " $1 }' | while read output;
do
  echo $output
  used=$(echo $output | awk '{ print $1}' | cut -d'%' -f1  )
  partition=$(echo $output | awk '{ print $2 }' )
  if [ $used -ge 65 ]; then
    echo "The partition \"$partition\" on $(hostname) has used $used% at $(date)" >> /root/info.txt
    echo "Disk space alert: $used% used" >> /root/info.txt
#echo "verifique o anexo" | mail -s "Checar urgente $(hostname)" -a /root/info.txt mauricio.figueiro@unicesumar.edu.br
    #echo "The partition \"$partition\" on $(hostname) has used $used% at $(date)" | echo "Disk space alert: $used% used" | mail -s "Checar urgente $(hostname)" mauricio.figueiro@unicesumar.edu.br
  fi
done

 if [ -f "$FILE" ]; then
sed -i '1 iESTE SERVIDOR FAZ PARTE DO BACKEND DO STUDEO (STUDEOAPI.UNICESUMAR.EDU.BR)' /root/info.txt
sed -i '2 i==========================================================' /root/info.txt
sed -i '3 i .' /root/info.txt
cat /root/info.txt | mail -s "$(hostname) Checar urgente o(s) disco(s)" -r "CHECK DISK STUDEOAPI<studeoapi@unicesumar.edu.br>" -a /root/info.txt ito.operacao@unicesumar.edu.br

 fi