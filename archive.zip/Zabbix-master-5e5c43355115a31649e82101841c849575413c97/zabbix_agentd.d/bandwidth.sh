#!/bin/bash
vnstat -u

i=$(vnstat -i eth0 --oneline | awk -F\; '{ print $11 }')

bandwidth_number=$(echo $i | awk '{ print $1 }')

bandwidth_unit=$(echo $i | awk '{ print $2 }')

case "$bandwidth_unit" in

#       KiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09951" | bc); echo "$bandwidth_number_MB KB";;

#       MiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09951" | bc); echo "$bandwidth_number_MB MB";;

#       GiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09951" | bc); echo "$bandwidth_number_MB GB";;

#       TiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09951" | bc); echo "$bandwidth_number_MB TB";;

        KiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09" | bc); echo "$bandwidth_number_MB KB";;

        MiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09" | bc); echo "$bandwidth_number_MB MB";;

        GiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09" | bc); echo "$bandwidth_number_MB GB";;

        TiB)    bandwidth_number_MB=$(echo "$bandwidth_number*1.09" | bc); echo "$bandwidth_number_MB TB";;

esac