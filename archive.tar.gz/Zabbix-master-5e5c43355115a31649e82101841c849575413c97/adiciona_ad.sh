#!/bin/bash

clear

main () {
echo -e "\e[1;31mBem vindo ao sistema de intregracao com Active Directory\e[0m"
echo -e "\e[1;31mO servidor \e[1;36m$HOSTNAME \e[1;31msera adicionado ao dominio \e[1;36mADM-CESUMAR.LOCAL\e[0m"
echo -e "\e[1;31mSelecione a opcao desejada:\e[0m"
echo -e "\e[1;31m1 - Adiciona ao dominio\e[0m"
echo -e "\e[1;31m2 - Remove do dominio\e[0m"
echo -e "\e[1;31m0 - Sair\e[0m"
echo -ne "\e[1;31mDigite sua opcao: \e[0m"

read resultado

case $resultado in

1) adiciona_ad;;
2) remove_ad;;
0) exit;;
*) echo -e "\e[1;31mOpcao invalida\e[0m"; echo ; main ;;
esac
}

adiciona_ad () {
echo
echo -n "Insira seu usuario: "
read usuario_do_ad

realm join "adm-cesumar.local" -U $usuario_do_ad --computer-ou=OU=ServidoresLinux,OU=Computadores
if [ $? = '0'  ]; then
        echo "Servidor adicionado com sucesso. Adicione o IP ao servidor DNS"
else
        echo "Erro ao adicionar servidor ao AD. Por favor verifique as configuracoes"
fi
exit 0 ;
}

remove_ad () {
echo
echo -ne "Insira seu usuario: "
read usuario_do_ad

realm leave --remove -U $usuario_do_ad
if [ $? = '0' ] then
        echo "Servidor removido. Remova as entradas do servidor DNS"
else
        echo "Erro ao remover servidor do AD. Por favor verifique as configuracoes"
fi
exit 0 ;
}

main