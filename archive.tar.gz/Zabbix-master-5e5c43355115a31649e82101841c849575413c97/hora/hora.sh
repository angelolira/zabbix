#!/bin/bash
# Menu Shell
DIR=/etc/
FILE=ntp.conf
FILE2=ntp.conf.orig

clear
menu ()
{
a="ok"

while true $a !="ok"
do
   echo "MENU PRINCIPAL"
   echo ""
   echo "1 - Atualizar com NTPDATE"
   echo "2 - Alterar Time Zone c/ timedatectl"
   echo "3 - Configurar cliente"
   echo "4 - Sair"
   echo ""
   echo "Digite a opção desejada: "
   read a
   case $a in
   1)
clear
ntpdate ntp.unicesumar.edu.br
echo ""
echo ""
echo ""
echo "EXECUTADO"
echo "EXECUTADO"
date
echo ""
echo ""
echo ""
echo ""
echo "";;
   2)timedatectl set-timezone America/Sao_Paulo
date;;
   3)

if [ -e "$DIR$FILE2" ] ; then
echo "Faz Nada, Verificar /etc/ntp.conf e /etc/ntp.conf.orig"
echo ""
echo "========================================================"
echo "========================================================"
echo ""

else

cp /etc/ntp.conf /etc/ntp.conf.orig
rm -f /etc/ntp.conf
echo "server ntp.unicesumar.edu.br iburst" >> /etc/ntp.conf
echo "server a.ntp.br iburst" >> /etc/ntp.conf
fi

#ativando servico
echo "========================================================"
echo ""
echo "ativando servico ntpd"
chkconfig ntpd on
echo "ativando servico ntpdate"
chkconfig ntpdate on
systemctl start ntpd.service
systemctl start ntpdate.service
;;

   4)exit;;
   esac
done
}

menu

