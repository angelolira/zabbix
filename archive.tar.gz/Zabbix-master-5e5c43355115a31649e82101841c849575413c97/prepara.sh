#!/bin/bash
FILE=/root/.ssh/authorized_keys
if test -f "$FILE"; then
    echo "$FILE exists."
    mkdir /root/.ssh/bkp-satellite
    cp $FILE /root/.ssh/bkp-satellite/authorized_keys-`date +"%Y%m%d_%H%M"`
    echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCc8aRJaUwGpobaBtOZoxO5BImezWOTY/PVindnszt/qQFaHrdaiSQ2W+oGu1tFUlzkTSiqXCeMF2pYFLI6Ilx0C/V7KlfhF6cBxhedAy6BxT3ptPh1WE1xK0KOoFTPLYrf07zZQSyi3QOpqm+0mstTG2yeYHt9NPHFP2B5xgHfkpvHEBgOYUq/azEIeEYWiIjAdTA9dYwPjPcZ9cHpieA4CrDHp9qWCFIHhn169c55iq9+y0iA4786AMMLDuee6L+vKgxi8zKM6zFQWz2vN1WtT2I2WXztqHTSdJfqmMBheI2FCJOkICzo42+orVWVtOj+Yl3FBReIpu6GHdP5TIL root@redhat-app46-c33" >> $FILE
    echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDD6vRa0A/P37ea2PHjC9Y/nhsuC0WRdtN8CAlf83PC8Qqfkr0SVxlCIKYBLIKhXiJ+YSQnyMDgy82+7h2A0bziJMo+TmRdOoSoy03+21ij20abq0x/afoJOxESyKngZPR2Cwidw4nPVGkZu6HkH2hfhAPpZg/vU5fPQi2mdxngEoksR5/nPN6oAlxQdGkIKN+VJctBVzdU1bTE5khbJ3Q7TRHx4W1PjvhxFjwLZ+4w4WwzfKT4aOmperx6/pbPmkmjEgWVDNHhVaqxolOpx2R9QPxOuWvSWUqeWV5pZhBeukYcBb3uclrHGNIId1iEg88PMsMCwXMcUjQ+6F0I5j7/ foreman-proxy@REDHAT-APP93" >> $FILE
   
else
    
    echo "nao existe - criando"
    mkdir /root/.ssh
    echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDCc8aRJaUwGpobaBtOZoxO5BImezWOTY/PVindnszt/qQFaHrdaiSQ2W+oGu1tFUlzkTSiqXCeMF2pYFLI6Ilx0C/V7KlfhF6cBxhedAy6BxT3ptPh1WE1xK0KOoFTPLYrf07zZQSyi3QOpqm+0mstTG2yeYHt9NPHFP2B5xgHfkpvHEBgOYUq/azEIeEYWiIjAdTA9dYwPjPcZ9cHpieA4CrDHp9qWCFIHhn169c55iq9+y0iA4786AMMLDuee6L+vKgxi8zKM6zFQWz2vN1WtT2I2WXztqHTSdJfqmMBheI2FCJOkICzo42+orVWVtOj+Yl3FBReIpu6GHdP5TIL root@redhat-app46-c33" >> $FILE
    echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDD6vRa0A/P37ea2PHjC9Y/nhsuC0WRdtN8CAlf83PC8Qqfkr0SVxlCIKYBLIKhXiJ+YSQnyMDgy82+7h2A0bziJMo+TmRdOoSoy03+21ij20abq0x/afoJOxESyKngZPR2Cwidw4nPVGkZu6HkH2hfhAPpZg/vU5fPQi2mdxngEoksR5/nPN6oAlxQdGkIKN+VJctBVzdU1bTE5khbJ3Q7TRHx4W1PjvhxFjwLZ+4w4WwzfKT4aOmperx6/pbPmkmjEgWVDNHhVaqxolOpx2R9QPxOuWvSWUqeWV5pZhBeukYcBb3uclrHGNIId1iEg88PMsMCwXMcUjQ+6F0I5j7/ foreman-proxy@REDHAT-APP93" >> $FILE

    chmod 600 $FILE
fi

cd /etc/yum.repos.d
mkdir /etc/yum.repos.d/bkp-satellite
mv /etc/yum.repos.d/* /etc/yum.repos.d/bkp-satellite/ 